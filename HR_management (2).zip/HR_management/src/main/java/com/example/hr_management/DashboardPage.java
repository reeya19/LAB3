package com.example.hr_management;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DashboardPage extends VBox {
    private Button adminButton;
    private Button employeeButton;
    private Button performanceButton;
    private Button onboardingButton;
    private Button leaveManagementButton;
    private Button logoutButton;
    private Button exitButton;
    private HRManagementYourName mainApp;

    public DashboardPage(HRManagementYourName mainApp) {
        this.mainApp = mainApp;
        this.setAlignment(Pos.CENTER);
        this.setSpacing(15);
        this.setPadding(new Insets(20));
        this.setStyle("-fx-background-color: #e6e6e6;");

        Label welcomeLabel = new Label("Welcome to HR Management Dashboard");
        welcomeLabel.setFont(Font.font("Arial", FontWeight.BOLD, 22));

        Label dateLabel = new Label("Date: " + LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy")));
        dateLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        adminButton = createStyledButton("Admin Panel", "#3498db");
        employeeButton = createStyledButton("Employee Management", "#2ecc71");
        performanceButton = createStyledButton("Performance Tracking", "#9b59b6");
        onboardingButton = createStyledButton("Onboarding", "#1abc9c");
        leaveManagementButton = createStyledButton("Leave Management", "#f39c12");
        logoutButton = createStyledButton("Logout", "#e74c3c");
        exitButton = createStyledButton("Exit", "#95a5a6");

        adminButton.setOnAction(e -> mainApp.showAdminPage());
        employeeButton.setOnAction(e -> mainApp.showEmployeePage());
        performanceButton.setOnAction(e -> mainApp.showPerformancePage());
        onboardingButton.setOnAction(e -> mainApp.showOnboardingPage());
        leaveManagementButton.setOnAction(e -> mainApp.showLeaveManagementPage());
        logoutButton.setOnAction(e -> mainApp.logout());
        exitButton.setOnAction(e -> mainApp.exit());

        this.getChildren().addAll(welcomeLabel, dateLabel, adminButton, employeeButton,
                performanceButton, onboardingButton, leaveManagementButton,
                logoutButton, exitButton);
    }

    private Button createStyledButton(String text, String color) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white;");
        button.setMinWidth(200);
        button.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        return button;
    }
}
