package com.example.hr_management;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import java.sql.*;
import java.time.LocalDate;
import java.util.Optional;

public class EmployeePage extends BorderPane {
    private TableView<Employee> tableView;
    private Button createButton;
    private Button updateButton;
    private Button deleteButton;
    private Button viewButton;
    private Button backButton;
    private HRManagementYourName mainApp;

    public EmployeePage(HRManagementYourName mainApp) {
        this.mainApp = mainApp;
        this.setPadding(new Insets(10));
        this.setStyle("-fx-background-color: #f0f8ff;");

        Label headerLabel = new Label("Employee Management");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        this.setTop(headerLabel);
        BorderPane.setMargin(headerLabel, new Insets(0, 0, 10, 0));

        setupTableView();

        // Test database connection
        try {
            Connection connection = DatabaseConnection.getConnection();
            if (connection != null) {
                System.out.println("Database connection successful!");
                connection.close(); // Close the connection after testing
            } else {
                System.err.println("Failed to connect to the database.");
                showAlert("Database Error", "Failed to connect to the database.");
            }
        } catch (SQLException e) {
            System.err.println("Database connection error: " + e.getMessage());
            showAlert("Database Error", "Database connection error: " + e.getMessage());
            e.printStackTrace();
        }

        loadEmployeesFromDatabase();

        this.setCenter(tableView);

        HBox buttonBox = new HBox(10);
        createButton = createStyledButton("Create", "#2ecc71");
        updateButton = createStyledButton("Update", "#f1c40f");
        deleteButton = createStyledButton("Delete", "#e74c3c");
        viewButton = createStyledButton("View", "#3498db");
        backButton = createStyledButton("Back", "#95a5a6");

        buttonBox.getChildren().addAll(createButton, updateButton, deleteButton, viewButton, backButton);
        this.setBottom(buttonBox);
        BorderPane.setMargin(buttonBox, new Insets(10, 0, 0, 0));

        backButton.setOnAction(e -> mainApp.showDashboard());
        createButton.setOnAction(e -> createEmployee());
        updateButton.setOnAction(e -> updateEmployee());
        deleteButton.setOnAction(e -> deleteEmployee());
        viewButton.setOnAction(e -> viewEmployee());
    }

    private void setupTableView() {
        tableView = new TableView<>();
        TableColumn<Employee, Number> idColumn = new TableColumn<>("Employee ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().empIdProperty());
        TableColumn<Employee, String> firstNameColumn = new TableColumn<>("First Name");
        firstNameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        TableColumn<Employee, String> lastNameColumn = new TableColumn<>("Last Name");
        lastNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
        TableColumn<Employee, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        TableColumn<Employee, String> phoneColumn = new TableColumn<>("Phone");
        phoneColumn.setCellValueFactory(cellData -> cellData.getValue().phoneProperty());
        TableColumn<Employee, LocalDate> hireDateColumn = new TableColumn<>("Hire Date");
        hireDateColumn.setCellValueFactory(cellData -> cellData.getValue().hireDateProperty());
        TableColumn<Employee, String> jobTitleColumn = new TableColumn<>("Job Title");
        jobTitleColumn.setCellValueFactory(cellData -> cellData.getValue().jobTitleProperty());
        tableView.getColumns().addAll(idColumn, firstNameColumn, lastNameColumn, emailColumn, phoneColumn, hireDateColumn, jobTitleColumn);
    }

    private void loadEmployeesFromDatabase() {
        ObservableList<Employee> employees = FXCollections.observableArrayList();
        String sql = "SELECT * FROM Employee";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt("emp_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getDate("hire_date").toLocalDate(),
                        rs.getString("job_title")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Error loading employees: " + e.getMessage());
        }

        tableView.setItems(employees);
    }

    private Button createStyledButton(String text, String color) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white;");
        button.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        return button;
    }

    private void createEmployee() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Create New Employee");
        dialog.setHeaderText("Enter Employee Details");
        dialog.setContentText("First Name,Last Name,Email,Phone,Hire Date (YYYY-MM-DD),Job Title (comma-separated):");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(data -> {
            String[] fields = data.split(",");
            if (fields.length == 6) {
                String sql = "INSERT INTO Employee (first_name, last_name, email, phone, hire_date, job_title) VALUES (?, ?, ?, ?, ?, ?)";
                try (Connection conn = DatabaseConnection.getConnection();
                     PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

                    pstmt.setString(1, fields[0].trim());
                    pstmt.setString(2, fields[1].trim());
                    pstmt.setString(3, fields[2].trim());
                    pstmt.setString(4, fields[3].trim());
                    pstmt.setDate(5, Date.valueOf(fields[4].trim()));
                    pstmt.setString(6, fields[5].trim());

                    int affectedRows = pstmt.executeUpdate();

                    if (affectedRows > 0) {
                        try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                            if (generatedKeys.next()) {
                                Employee newEmployee = new Employee(
                                        generatedKeys.getInt(1),
                                        fields[0].trim(),
                                        fields[1].trim(),
                                        fields[2].trim(),
                                        fields[3].trim(),
                                        LocalDate.parse(fields[4].trim()),
                                        fields[5].trim()
                                );
                                tableView.getItems().add(newEmployee);
                            }
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert("Database Error", "Error creating new employee.");
                }
            } else {
                showAlert("Invalid Input", "Please enter all required fields.");
            }
        });
    }

    private void updateEmployee() {
        Employee selectedEmployee = tableView.getSelectionModel().getSelectedItem();
        if (selectedEmployee != null) {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Update Employee");
            dialog.setHeaderText("Update Employee Details");
            dialog.setContentText("First Name,Last Name,Email,Phone,Hire Date (YYYY-MM-DD),Job Title (comma-separated):");

            Optional<String> result = dialog.showAndWait();
            result.ifPresent(data -> {
                String[] fields = data.split(",");
                if (fields.length == 6) {
                    String sql = "UPDATE Employee SET first_name = ?, last_name = ?, email = ?, phone = ?, hire_date = ?, job_title = ? WHERE emp_id = ?";
                    try (Connection conn = DatabaseConnection.getConnection();
                         PreparedStatement pstmt = conn.prepareStatement(sql)) {

                        pstmt.setString(1, fields[0].trim());
                        pstmt.setString(2, fields[1].trim());
                        pstmt.setString(3, fields[2].trim());
                        pstmt.setString(4, fields[3].trim());
                        pstmt.setDate(5, Date.valueOf(fields[4].trim()));
                        pstmt.setString(6, fields[5].trim());
                        pstmt.setInt(7, selectedEmployee.getEmpId());

                        int affectedRows = pstmt.executeUpdate();

                        if (affectedRows > 0) {
                            selectedEmployee.setFirstName(fields[0].trim());
                            selectedEmployee.setLastName(fields[1].trim());
                            selectedEmployee.setEmail(fields[2].trim());
                            selectedEmployee.setPhone(fields[3].trim());
                            selectedEmployee.setHireDate(LocalDate.parse(fields[4].trim()));
                            selectedEmployee.setJobTitle(fields[5].trim());
                            tableView.refresh();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                        showAlert("Database Error", "Error updating employee.");
                    }
                } else {
                    showAlert("Invalid Input", "Please enter all required fields.");
                }
            });
        } else {
            showAlert("No Selection", "Please select an employee to update.");
        }
    }

    private void deleteEmployee() {
        Employee selectedEmployee = tableView.getSelectionModel().getSelectedItem();
        if (selectedEmployee != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Employee");
            alert.setHeaderText("Are you sure you want to delete this employee?");
            alert.setContentText("Employee ID: " + selectedEmployee.getEmpId());

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                String sql = "DELETE FROM Employee WHERE emp_id = ?";
                try (Connection conn = DatabaseConnection.getConnection();
                     PreparedStatement pstmt = conn.prepareStatement(sql)) {

                    pstmt.setInt(1, selectedEmployee.getEmpId());
                    int affectedRows = pstmt.executeUpdate();

                    if (affectedRows > 0) {
                        tableView.getItems().remove(selectedEmployee);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert("Database Error", "Error deleting employee.");
                }
            }
        } else {
            showAlert("No Selection", "Please select an employee to delete.");
        }
    }

    private void viewEmployee() {
        Employee selectedEmployee = tableView.getSelectionModel().getSelectedItem();
        if (selectedEmployee != null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Employee Details");
            alert.setHeaderText("Employee Information");
            alert.setContentText("ID: " + selectedEmployee.getEmpId() +
                    "\nFirst Name: " + selectedEmployee.getFirstName() +
                    "\nLast Name: " + selectedEmployee.getLastName() +
                    "\nEmail: " + selectedEmployee.getEmail() +
                    "\nPhone: " + selectedEmployee.getPhone() +
                    "\nHire Date: " + selectedEmployee.getHireDate() +
                    "\nJob Title: " + selectedEmployee.getJobTitle());
            alert.showAndWait();
        } else {
            showAlert("No Selection", "Please select an employee to view.");
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
