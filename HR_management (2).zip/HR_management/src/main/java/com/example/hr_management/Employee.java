package com.example.hr_management;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.ObjectProperty;
import java.time.LocalDate;

public class Employee {
    private final IntegerProperty empId;
    private final StringProperty firstName;
    private final StringProperty lastName;
    private final StringProperty email;
    private final StringProperty phone;
    private final ObjectProperty<LocalDate> hireDate;
    private final StringProperty jobTitle;

    public Employee(int empId, String firstName, String lastName, String email, String phone, LocalDate hireDate, String jobTitle) {
        this.empId = new SimpleIntegerProperty(empId);
        this.firstName = new SimpleStringProperty(firstName);
        this.lastName = new SimpleStringProperty(lastName);
        this.email = new SimpleStringProperty(email);
        this.phone = new SimpleStringProperty(phone);
        this.hireDate = new SimpleObjectProperty<>(hireDate);
        this.jobTitle = new SimpleStringProperty(jobTitle);
    }

    // Getters
    public int getEmpId() { return empId.get(); }
    public String getFirstName() { return firstName.get(); }
    public String getLastName() { return lastName.get(); }
    public String getEmail() { return email.get(); }
    public String getPhone() { return phone.get(); }
    public LocalDate getHireDate() { return hireDate.get(); }
    public String getJobTitle() { return jobTitle.get(); }

    // Property getters
    public IntegerProperty empIdProperty() { return empId; }
    public StringProperty firstNameProperty() { return firstName; }
    public StringProperty lastNameProperty() { return lastName; }
    public StringProperty emailProperty() { return email; }
    public StringProperty phoneProperty() { return phone; }
    public ObjectProperty<LocalDate> hireDateProperty() { return hireDate; }
    public StringProperty jobTitleProperty() { return jobTitle; }

    // Setters
    public void setEmpId(int empId) { this.empId.set(empId); }
    public void setFirstName(String firstName) { this.firstName.set(firstName); }
    public void setLastName(String lastName) { this.lastName.set(lastName); }
    public void setEmail(String email) { this.email.set(email); }
    public void setPhone(String phone) { this.phone.set(phone); }
    public void setHireDate(LocalDate hireDate) { this.hireDate.set(hireDate); }
    public void setJobTitle(String jobTitle) { this.jobTitle.set(jobTitle); }
}
