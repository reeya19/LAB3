package com.example.hr_management;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import java.util.Optional;

public class AdminPage extends BorderPane {
    private TableView<Admin> tableView;
    private Button createButton;
    private Button updateButton;
    private Button deleteButton;
    private Button viewButton;
    private Button backButton;
    private HRManagementYourName mainApp;

    public AdminPage(HRManagementYourName mainApp) {
        this.mainApp = mainApp;
        this.setPadding(new Insets(10));
        this.setStyle("-fx-background-color: #f5f5f5;");

        Label headerLabel = new Label("Admin Management");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        this.setTop(headerLabel);
        BorderPane.setMargin(headerLabel, new Insets(0, 0, 10, 0));

        tableView = new TableView<>();
        TableColumn<Admin, String> idColumn = new TableColumn<>("Admin ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().adminIdProperty());
        TableColumn<Admin, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        TableColumn<Admin, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        TableColumn<Admin, String> roleColumn = new TableColumn<>("Role");
        roleColumn.setCellValueFactory(cellData -> cellData.getValue().roleProperty());
        tableView.getColumns().addAll(idColumn, nameColumn, emailColumn, roleColumn);

        // Add sample data
        ObservableList<Admin> admins = FXCollections.observableArrayList(
                new Admin("A001", "John Doe", "johndoe@example.com", "Super Admin"),
                new Admin("A002", "Jane Smith", "janesmith@example.com", "HR Admin"),
                new Admin("A003", "Bob Johnson", "bobjohnson@example.com", "IT Admin")
        );
        tableView.setItems(admins);

        this.setCenter(tableView);

        HBox buttonBox = new HBox(10);
        createButton = createStyledButton("Create", "#27ae60");
        updateButton = createStyledButton("Update", "#f39c12");
        deleteButton = createStyledButton("Delete", "#c0392b");
        viewButton = createStyledButton("View", "#3498db");
        backButton = createStyledButton("Back", "#95a5a6");

        buttonBox.getChildren().addAll(createButton, updateButton, deleteButton, viewButton, backButton);
        this.setBottom(buttonBox);
        BorderPane.setMargin(buttonBox, new Insets(10, 0, 0, 0));

        backButton.setOnAction(e -> mainApp.showDashboard());
        createButton.setOnAction(e -> createAdmin());
        updateButton.setOnAction(e -> updateAdmin());
        deleteButton.setOnAction(e -> deleteAdmin());
        viewButton.setOnAction(e -> viewAdmin());
    }

    private Button createStyledButton(String text, String color) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white;");
        button.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        return button;
    }

    private void createAdmin() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Create New Admin");
        dialog.setHeaderText("Enter Admin Details");
        dialog.setContentText("Admin ID,Name,Email,Role (comma-separated):");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(data -> {
            String[] fields = data.split(",");
            if (fields.length == 4) {
                Admin newAdmin = new Admin(fields[0].trim(), fields[1].trim(), fields[2].trim(), fields[3].trim());
                tableView.getItems().add(newAdmin);
            } else {
                showAlert("Invalid Input", "Please enter all required fields.");
            }
        });
    }

    private void updateAdmin() {
        Admin selectedAdmin = tableView.getSelectionModel().getSelectedItem();
        if (selectedAdmin != null) {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Update Admin");
            dialog.setHeaderText("Update Admin Details");
            dialog.setContentText("Name,Email,Role (comma-separated):");

            Optional<String> result = dialog.showAndWait();
            result.ifPresent(data -> {
                String[] fields = data.split(",");
                if (fields.length == 3) {
                    selectedAdmin.setName(fields[0].trim());
                    selectedAdmin.setEmail(fields[1].trim());
                    selectedAdmin.setRole(fields[2].trim());
                    tableView.refresh();
                } else {
                    showAlert("Invalid Input", "Please enter all required fields.");
                }
            });
        } else {
            showAlert("No Selection", "Please select an admin to update.");
        }
    }

    private void deleteAdmin() {
        Admin selectedAdmin = tableView.getSelectionModel().getSelectedItem();
        if (selectedAdmin != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Admin");
            alert.setHeaderText("Are you sure you want to delete this admin?");
            alert.setContentText("Admin ID: " + selectedAdmin.getAdminId());

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                tableView.getItems().remove(selectedAdmin);
            }
        } else {
            showAlert("No Selection", "Please select an admin to delete.");
        }
    }

    private void viewAdmin() {
        Admin selectedAdmin = tableView.getSelectionModel().getSelectedItem();
        if (selectedAdmin != null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Admin Details");
            alert.setHeaderText("Admin Information");
            alert.setContentText("ID: " + selectedAdmin.getAdminId() +
                    "\nName: " + selectedAdmin.getName() +
                    "\nEmail: " + selectedAdmin.getEmail() +
                    "\nRole: " + selectedAdmin.getRole());
            alert.showAndWait();
        } else {
            showAlert("No Selection", "Please select an admin to view.");
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
