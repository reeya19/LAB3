package com.example.hr_management;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class LoginPage extends VBox {
    private TextField emailField;
    private PasswordField passwordField;
    private Button loginButton;
    private HRManagementYourName mainApp;

    public LoginPage(HRManagementYourName mainApp) {
        this.mainApp = mainApp;
        this.setAlignment(Pos.CENTER);
        this.setSpacing(15);
        this.setPadding(new Insets(20));
        this.setStyle("-fx-background-color: #f0f0f0;");

        Label titleLabel = new Label("HR Management System");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.DARKBLUE);

        emailField = new TextField();
        emailField.setPromptText("Enter your email");
        emailField.setMaxWidth(250);

        passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");
        passwordField.setMaxWidth(250);

        loginButton = new Button("Login");
        loginButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        loginButton.setOnAction(e -> login());

        this.getChildren().addAll(titleLabel, emailField, passwordField, loginButton);
    }

    private void login() {
        String email = emailField.getText();
        String password = passwordField.getText();

        if (isValidCredentials(email, password)) {
            mainApp.showDashboard();
        } else {
            showAlert("Login Failed", "Invalid email or password. Please try again.");
        }
    }

    private boolean isValidCredentials(String email, String password) {
        return email.equals("Lovishbatra.2004@gmail.com") && password.equals("lovish28");
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
