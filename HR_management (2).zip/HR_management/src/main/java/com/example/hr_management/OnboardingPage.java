package com.example.hr_management;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.time.LocalDate;
import java.util.Optional;

public class OnboardingPage extends VBox {
    private ComboBox<String> employeeSelector;
    private ListView<OnboardingTask> taskList;
    private Button completeTaskButton;
    private Button addTaskButton;
    private Button deleteTaskButton;
    private Button updateTaskButton;
    private Button generateReportButton;
    private Button backButton;
    private Label progressLabel;
    private ProgressBar progressBar;
    private HRManagementYourName mainApp;

    public OnboardingPage(HRManagementYourName mainApp) {
        this.mainApp = mainApp;
        this.setPadding(new Insets(20));
        this.setSpacing(15);
        this.setStyle("-fx-background-color: #e0f7fa;");

        Label headerLabel = new Label("Advanced Onboarding Process");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        employeeSelector = new ComboBox<>();
        employeeSelector.setPromptText("Select Employee");
        employeeSelector.getItems().addAll("John Doe", "Jane Smith", "Alice Johnson");
        employeeSelector.setOnAction(e -> loadTasksForEmployee());

        taskList = new ListView<>();
        taskList.setCellFactory(param -> new ListCell<OnboardingTask>() {
            @Override
            protected void updateItem(OnboardingTask item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getDescription() + " (Due: " + item.getDueDate() + ")");
                    setStyle(item.isCompleted() ? "-fx-text-fill: green;" : "-fx-text-fill: black;");
                }
            }
        });

        HBox buttonBox = new HBox(10);
        completeTaskButton = new Button("Mark Task as Complete");
        completeTaskButton.setOnAction(e -> completeTask());
        addTaskButton = new Button("Add New Task");
        addTaskButton.setOnAction(e -> addNewTask());
        deleteTaskButton = new Button("Delete Task");
        deleteTaskButton.setOnAction(e -> deleteTask());
        updateTaskButton = new Button("Update Task");
        updateTaskButton.setOnAction(e -> updateTask());
        generateReportButton = new Button("Generate Report");
        generateReportButton.setOnAction(e -> generateReport());
        backButton = new Button("Back to Dashboard");
        backButton.setOnAction(e -> mainApp.showDashboard());
        buttonBox.getChildren().addAll(completeTaskButton, addTaskButton, deleteTaskButton, updateTaskButton, generateReportButton, backButton);

        progressLabel = new Label("Onboarding Progress: 0%");
        progressBar = new ProgressBar(0);
        progressBar.setMaxWidth(Double.MAX_VALUE);

        this.getChildren().addAll(headerLabel, employeeSelector, taskList, buttonBox, progressLabel, progressBar);
    }

    private void loadTasksForEmployee() {
        // In a real application, this would load tasks from a database
        ObservableList<OnboardingTask> tasks = FXCollections.observableArrayList(
                new OnboardingTask("Complete new hire paperwork", LocalDate.now().plusDays(1)),
                new OnboardingTask("Set up company email", LocalDate.now().plusDays(2)),
                new OnboardingTask("Review company policies", LocalDate.now().plusDays(3)),
                new OnboardingTask("Complete orientation training", LocalDate.now().plusDays(5)),
                new OnboardingTask("Meet with team members", LocalDate.now().plusDays(7)),
                new OnboardingTask("Set up workstation", LocalDate.now().plusDays(1))
        );
        taskList.setItems(tasks);
        updateProgress();
    }

    private void completeTask() {
        OnboardingTask selectedTask = taskList.getSelectionModel().getSelectedItem();
        if (selectedTask != null) {
            selectedTask.setCompleted(true);
            taskList.refresh();
            updateProgress();
        } else {
            showAlert("No Task Selected", "Please select a task to mark as complete.");
        }
    }

    private void addNewTask() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add New Task");
        dialog.setHeaderText("Enter task details");
        dialog.setContentText("Task description:");

        dialog.showAndWait().ifPresent(description -> {
            OnboardingTask newTask = new OnboardingTask(description, LocalDate.now().plusWeeks(1));
            taskList.getItems().add(newTask);
            updateProgress();
        });
    }

    private void deleteTask() {
        OnboardingTask selectedTask = taskList.getSelectionModel().getSelectedItem();
        if (selectedTask != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Task");
            alert.setHeaderText("Are you sure you want to delete this task?");
            alert.setContentText(selectedTask.getDescription());

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                taskList.getItems().remove(selectedTask);
                updateProgress();
            }
        } else {
            showAlert("No Task Selected", "Please select a task to delete.");
        }
    }

    private void updateTask() {
        OnboardingTask selectedTask = taskList.getSelectionModel().getSelectedItem();
        if (selectedTask != null) {
            TextInputDialog dialog = new TextInputDialog(selectedTask.getDescription());
            dialog.setTitle("Update Task");
            dialog.setHeaderText("Update task details");
            dialog.setContentText("Task description:");

            dialog.showAndWait().ifPresent(description -> {
                selectedTask.setDescription(description);
                taskList.refresh();
            });
        } else {
            showAlert("No Task Selected", "Please select a task to update.");
        }
    }

    private void generateReport() {
        StringBuilder report = new StringBuilder();
        report.append("Onboarding Report for ").append(employeeSelector.getValue()).append("\n\n");

        for (OnboardingTask task : taskList.getItems()) {
            report.append(task.isCompleted() ? "[X] " : "[ ] ")
                    .append(task.getDescription())
                    .append(" (Due: ").append(task.getDueDate()).append(")\n");
        }

        TextArea reportArea = new TextArea(report.toString());
        reportArea.setEditable(false);
        reportArea.setWrapText(true);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Onboarding Report");
        alert.setHeaderText("Onboarding Progress Report");
        alert.getDialogPane().setContent(reportArea);
        alert.showAndWait();
    }

    private void updateProgress() {
        int totalTasks = taskList.getItems().size();
        int completedTasks = (int) taskList.getItems().stream().filter(OnboardingTask::isCompleted).count();
        double progress = totalTasks > 0 ? (double) completedTasks / totalTasks : 0;
        progressBar.setProgress(progress);
        progressLabel.setText(String.format("Onboarding Progress: %.0f%%", progress * 100));
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private static class OnboardingTask {
        private String description;
        private final LocalDate dueDate;
        private boolean completed;

        public OnboardingTask(String description, LocalDate dueDate) {
            this.description = description;
            this.dueDate = dueDate;
            this.completed = false;
        }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public LocalDate getDueDate() { return dueDate; }
        public boolean isCompleted() { return completed; }
        public void setCompleted(boolean completed) { this.completed = completed; }
    }
}
