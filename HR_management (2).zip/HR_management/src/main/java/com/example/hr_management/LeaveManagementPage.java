package com.example.hr_management;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.time.LocalDate;
import java.util.Optional;

public class LeaveManagementPage extends BorderPane {
    private TableView<LeaveRequest> leaveRequestsTable;
    private Button requestLeaveButton;
    private Button approveLeaveButton;
    private Button rejectLeaveButton;
    private Button backButton;
    private ComboBox<String> leaveTypeFilter;
    private DatePicker dateFilter;
    private PieChart leaveDistributionChart;
    private HRManagementYourName mainApp;

    public LeaveManagementPage(HRManagementYourName mainApp) {
        this.mainApp = mainApp;
        this.setPadding(new Insets(10));
        this.setStyle("-fx-background-color: #fff8e1;");

        Label headerLabel = new Label("Leave Management");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        this.setTop(headerLabel);

        leaveRequestsTable = new TableView<>();
        TableColumn<LeaveRequest, String> employeeColumn = new TableColumn<>("Employee");
        employeeColumn.setCellValueFactory(cellData -> cellData.getValue().employeeProperty());
        TableColumn<LeaveRequest, String> leaveTypeColumn = new TableColumn<>("Leave Type");
        leaveTypeColumn.setCellValueFactory(cellData -> cellData.getValue().leaveTypeProperty());
        TableColumn<LeaveRequest, String> startDateColumn = new TableColumn<>("Start Date");
        startDateColumn.setCellValueFactory(cellData -> cellData.getValue().startDateProperty());
        TableColumn<LeaveRequest, String> endDateColumn = new TableColumn<>("End Date");
        endDateColumn.setCellValueFactory(cellData -> cellData.getValue().endDateProperty());
        TableColumn<LeaveRequest, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(cellData -> cellData.getValue().statusProperty());

        leaveRequestsTable.getColumns().addAll(employeeColumn, leaveTypeColumn, startDateColumn, endDateColumn, statusColumn);

        // Add some sample data
        ObservableList<LeaveRequest> leaveRequests = FXCollections.observableArrayList(
                new LeaveRequest("John Doe", "Annual Leave", "2025-03-01", "2025-03-05", "Pending"),
                new LeaveRequest("Jane Smith", "Sick Leave", "2025-03-10", "2025-03-12", "Approved"),
                new LeaveRequest("Bob Johnson", "Personal Leave", "2025-03-15", "2025-03-20", "Pending")
        );
        leaveRequestsTable.setItems(leaveRequests);

        leaveTypeFilter = new ComboBox<>();
        leaveTypeFilter.getItems().addAll("All", "Annual Leave", "Sick Leave", "Personal Leave");
        leaveTypeFilter.setValue("All");
        leaveTypeFilter.setOnAction(e -> filterLeaveRequests());

        dateFilter = new DatePicker();
        dateFilter.setOnAction(e -> filterLeaveRequests());

        HBox filterBox = new HBox(10, new Label("Leave Type:"), leaveTypeFilter, new Label("Date:"), dateFilter);

        leaveDistributionChart = new PieChart();
        leaveDistributionChart.setTitle("Leave Distribution");
        updateLeaveDistributionChart();

        HBox buttonBox = new HBox(10);
        requestLeaveButton = new Button("Request Leave");
        approveLeaveButton = new Button("Approve Selected Leave");
        rejectLeaveButton = new Button("Reject Selected Leave");
        backButton = new Button("Back to Dashboard");

        requestLeaveButton.setOnAction(e -> requestLeave());
        approveLeaveButton.setOnAction(e -> approveLeave());
        rejectLeaveButton.setOnAction(e -> rejectLeave());
        backButton.setOnAction(e -> mainApp.showDashboard());

        buttonBox.getChildren().addAll(requestLeaveButton, approveLeaveButton, rejectLeaveButton, backButton);

        VBox leftPanel = new VBox(10, filterBox, leaveRequestsTable, buttonBox);
        this.setLeft(leftPanel);
        this.setCenter(leaveDistributionChart);
    }

    private void filterLeaveRequests() {
        String selectedLeaveType = leaveTypeFilter.getValue();
        LocalDate selectedDate = dateFilter.getValue();

        ObservableList<LeaveRequest> filteredList = leaveRequestsTable.getItems().filtered(request -> {
            boolean matchesType = "All".equals(selectedLeaveType) || selectedLeaveType.equals(request.getLeaveType());
            boolean matchesDate = selectedDate == null ||
                    (LocalDate.parse(request.getStartDate()).compareTo(selectedDate) <= 0 &&
                            LocalDate.parse(request.getEndDate()).compareTo(selectedDate) >= 0);
            return matchesType && matchesDate;
        });

        leaveRequestsTable.setItems(filteredList);
        updateLeaveDistributionChart();
    }

    private void requestLeave() {
        Dialog<LeaveRequest> dialog = new Dialog<>();
        dialog.setTitle("Request Leave");
        dialog.setHeaderText("Enter Leave Details");

        ButtonType submitButtonType = new ButtonType("Submit", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(submitButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField employeeName = new TextField();
        ComboBox<String> leaveType = new ComboBox<>();
        leaveType.getItems().addAll("Annual Leave", "Sick Leave", "Personal Leave");
        DatePicker startDate = new DatePicker();
        DatePicker endDate = new DatePicker();

        grid.add(new Label("Employee Name:"), 0, 0);
        grid.add(employeeName, 1, 0);
        grid.add(new Label("Leave Type:"), 0, 1);
        grid.add(leaveType, 1, 1);
        grid.add(new Label("Start Date:"), 0, 2);
        grid.add(startDate, 1, 2);
        grid.add(new Label("End Date:"), 0, 3);
        grid.add(endDate, 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == submitButtonType) {
                return new LeaveRequest(
                        employeeName.getText(),
                        leaveType.getValue(),
                        startDate.getValue().toString(),
                        endDate.getValue().toString(),
                        "Pending"
                );
            }
            return null;
        });

        Optional<LeaveRequest> result = dialog.showAndWait();
        result.ifPresent(leaveRequest -> {
            leaveRequestsTable.getItems().add(leaveRequest);
            updateLeaveDistributionChart();
        });
    }

    private void approveLeave() {
        LeaveRequest selectedRequest = leaveRequestsTable.getSelectionModel().getSelectedItem();
        if (selectedRequest != null) {
            selectedRequest.setStatus("Approved");
            leaveRequestsTable.refresh();
            updateLeaveDistributionChart();
        } else {
            showAlert("No Selection", "Please select a leave request to approve.");
        }
    }

    private void rejectLeave() {
        LeaveRequest selectedRequest = leaveRequestsTable.getSelectionModel().getSelectedItem();
        if (selectedRequest != null) {
            selectedRequest.setStatus("Rejected");
            leaveRequestsTable.refresh();
            updateLeaveDistributionChart();
        } else {
            showAlert("No Selection", "Please select a leave request to reject.");
        }
    }

    private void updateLeaveDistributionChart() {
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Annual Leave", 0),
                new PieChart.Data("Sick Leave", 0),
                new PieChart.Data("Personal Leave", 0)
        );

        for (LeaveRequest request : leaveRequestsTable.getItems()) {
            for (PieChart.Data data : pieChartData) {
                if (data.getName().equals(request.getLeaveType())) {
                    data.setPieValue(data.getPieValue() + 1);
                    break;
                }
            }
        }

        leaveDistributionChart.setData(pieChartData);
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

class LeaveRequest {
    private final StringProperty employee;
    private final StringProperty leaveType;
    private final StringProperty startDate;
    private final StringProperty endDate;
    private final StringProperty status;

    public LeaveRequest(String employee, String leaveType, String startDate, String endDate, String status) {
        this.employee = new SimpleStringProperty(employee);
        this.leaveType = new SimpleStringProperty(leaveType);
        this.startDate = new SimpleStringProperty(startDate);
        this.endDate = new SimpleStringProperty(endDate);
        this.status = new SimpleStringProperty(status);
    }

    public String getEmployee() { return employee.get(); }
    public void setEmployee(String value) { employee.set(value); }
    public StringProperty employeeProperty() { return employee; }

    public String getLeaveType() { return leaveType.get(); }
    public void setLeaveType(String value) { leaveType.set(value); }
    public StringProperty leaveTypeProperty() { return leaveType; }

    public String getStartDate() { return startDate.get(); }
    public void setStartDate(String value) { startDate.set(value); }
    public StringProperty startDateProperty() { return startDate; }

    public String getEndDate() { return endDate.get(); }
    public void setEndDate(String value) { endDate.set(value); }
    public StringProperty endDateProperty() { return endDate; }

    public String getStatus() { return status.get(); }
    public void setStatus(String value) { status.set(value); }
    public StringProperty statusProperty() { return status; }
}
