package com.example.hr_management;

import javafx.geometry.Insets;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import java.util.Random;

public class PerformanceTrackingPage extends BorderPane {
    private TableView<PerformanceMetric> metricsTable;
    private LineChart<String, Number> performanceChart;
    private ComboBox<String> employeeSelector;
    private ComboBox<String> metricSelector;
    private Button addMetricButton;
    private Button generateReportButton;
    private Button backButton;
    private HRManagementYourName mainApp;

    public PerformanceTrackingPage(HRManagementYourName mainApp) {
        this.mainApp = mainApp;
        this.setPadding(new Insets(10));
        this.setStyle("-fx-background-color: #e8e8e8;");

        Label headerLabel = new Label("Performance Tracking");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        this.setTop(headerLabel);
        BorderPane.setMargin(headerLabel, new Insets(0, 0, 10, 0));

        employeeSelector = new ComboBox<>();
        employeeSelector.getItems().addAll("Employee 1", "Employee 2", "Employee 3");
        employeeSelector.setPromptText("Select an employee");

        metricSelector = new ComboBox<>();
        metricSelector.getItems().addAll("Productivity", "Quality", "Attendance");
        metricSelector.setPromptText("Select a metric");

        metricsTable = new TableView<>();
        TableColumn<PerformanceMetric, String> metricColumn = new TableColumn<>("Metric");
        metricColumn.setCellValueFactory(cellData -> cellData.getValue().metricProperty());
        TableColumn<PerformanceMetric, String> valueColumn = new TableColumn<>("Value (%)");
        valueColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.format("%.2f%%", cellData.getValue().getValue())));
        metricsTable.getColumns().addAll(metricColumn, valueColumn);

        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis(0, 100, 10);
        yAxis.setLabel("Percentage");
        performanceChart = new LineChart<>(xAxis, yAxis);
        performanceChart.setTitle("Performance Over Time (%)");

        addMetricButton = new Button("Add Metric");
        addMetricButton.setOnAction(e -> addMetric());

        generateReportButton = new Button("Generate Report");
        generateReportButton.setOnAction(e -> generateReport());

        backButton = new Button("Back to Dashboard");
        backButton.setOnAction(e -> mainApp.showDashboard());

        VBox leftPanel = new VBox(10, employeeSelector, metricSelector, metricsTable, addMetricButton, generateReportButton, backButton);
        this.setLeft(leftPanel);
        this.setCenter(performanceChart);

        employeeSelector.setOnAction(e -> updatePerformanceData());
        metricSelector.setOnAction(e -> updatePerformanceData());
    }

    private void updatePerformanceData() {
        String selectedEmployee = employeeSelector.getValue();
        String selectedMetric = metricSelector.getValue();
        if (selectedEmployee != null && selectedMetric != null) {
            // Clear existing data
            metricsTable.getItems().clear();
            performanceChart.getData().clear();

            // Add dummy data based on selected employee and metric
            Random random = new Random(selectedEmployee.hashCode() + selectedMetric.hashCode());
            ObservableList<PerformanceMetric> metrics = FXCollections.observableArrayList();
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName(selectedMetric);

            for (int i = 1; i <= 12; i++) {
                double value = 70 + random.nextDouble() * 30; // Random value between 70 and 100
                metrics.add(new PerformanceMetric("Month " + i, value));
                series.getData().add(new XYChart.Data<>("Month " + i, value));
            }

            metricsTable.setItems(metrics);
            performanceChart.getData().add(series);
        }
    }

    private void addMetric() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add New Metric");
        dialog.setHeaderText("Enter new metric details");
        dialog.setContentText("Metric name:");

        dialog.showAndWait().ifPresent(metricName -> {
            metricSelector.getItems().add(metricName);
            metricSelector.setValue(metricName);
            updatePerformanceData();
        });
    }

    private void generateReport() {
        String selectedEmployee = employeeSelector.getValue();
        if (selectedEmployee != null) {
            StringBuilder report = new StringBuilder();
            report.append("Performance Report for ").append(selectedEmployee).append("\n\n");

            for (PerformanceMetric metric : metricsTable.getItems()) {
                report.append(metric.getMetric()).append(": ").append(String.format("%.2f%%", metric.getValue())).append("\n");
            }

            TextArea reportArea = new TextArea(report.toString());
            reportArea.setEditable(false);
            reportArea.setWrapText(true);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Performance Report");
            alert.setHeaderText("Performance Report for " + selectedEmployee);
            alert.getDialogPane().setContent(reportArea);
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Employee Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select an employee to generate a report.");
            alert.showAndWait();
        }
    }
}

class PerformanceMetric {
    private String metric;
    private double value;

    public PerformanceMetric(String metric, double value) {
        this.metric = metric;
        this.value = value;
    }

    public String getMetric() {
        return metric;
    }

    public double getValue() {
        return value;
    }

    public javafx.beans.property.StringProperty metricProperty() {
        return new javafx.beans.property.SimpleStringProperty(metric);
    }

    public javafx.beans.property.DoubleProperty valueProperty() {
        return new javafx.beans.property.SimpleDoubleProperty(value);
    }
}
