package com.example.hr_management;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HRManagementYourName extends Application {

    private Stage primaryStage;
    private Scene loginScene;
    private Scene dashboardScene;
    private Scene adminScene;
    private Scene employeeScene;
    private Scene performanceScene;
    private Scene onboardingScene;
    private Scene leaveManagementScene;

    private LoginPage loginPage;
    private DashboardPage dashboardPage;
    private AdminPage adminPage;
    private EmployeePage employeePage;
    private PerformanceTrackingPage performancePage;
    private OnboardingPage onboardingPage;
    private LeaveManagementPage leaveManagementPage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Advanced HR Management System");

        // Initialize Pages
        loginPage = new LoginPage(this);
        dashboardPage = new DashboardPage(this);
        adminPage = new AdminPage(this);
        employeePage = new EmployeePage(this);
        performancePage = new PerformanceTrackingPage(this);
        onboardingPage = new OnboardingPage(this);
        leaveManagementPage = new LeaveManagementPage(this);

        // Initialize Scenes
        loginScene = new Scene(loginPage, 300, 200);
        dashboardScene = new Scene(dashboardPage, 800, 600);
        adminScene = new Scene(adminPage, 800, 600);
        employeeScene = new Scene(employeePage, 800, 600);
        performanceScene = new Scene(performancePage, 800, 600);
        onboardingScene = new Scene(onboardingPage, 800, 600);
        leaveManagementScene = new Scene(leaveManagementPage, 800, 600);

        showLoginPage();
    }

    public void showLoginPage() {
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    public void showDashboard() {
        primaryStage.setScene(dashboardScene);
    }

    public void showAdminPage() {
        primaryStage.setScene(adminScene);
    }

    public void showEmployeePage() {
        primaryStage.setScene(employeeScene);
    }

    public void showPerformancePage() {
        primaryStage.setScene(performanceScene);
    }

    public void showOnboardingPage() {
        primaryStage.setScene(onboardingScene);
    }

    public void showLeaveManagementPage() {
        primaryStage.setScene(leaveManagementScene);
    }

    public void logout() {
        showLoginPage();
    }

    public void exit() {
        primaryStage.close();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
